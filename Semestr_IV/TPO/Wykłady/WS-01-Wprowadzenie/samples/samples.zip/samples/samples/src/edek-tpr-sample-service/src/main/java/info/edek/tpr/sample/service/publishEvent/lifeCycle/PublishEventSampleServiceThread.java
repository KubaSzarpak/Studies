package info.edek.tpr.sample.service.publishEvent.lifeCycle;

import info.edek.tpr.sample.service.publishEvent.PublishEventSampleServiceCommons;
import info.edek.tpr.sample.service.util.Service;
import info.edek.tpr.sample.service.util.Utility;

import java.util.List;
import java.util.Random;

import org.apache.axiom.om.OMAbstractFactory;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMFactory;
import org.apache.axiom.om.OMNamespace;
import org.apache.axis2.AxisFault;
import org.apache.axis2.addressing.EndpointReference;
import org.apache.axis2.client.ServiceClient;
import org.apache.axis2.description.AxisService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.impl.Log4JLogger;

public class PublishEventSampleServiceThread extends Thread {

	private static final long SLEEP_TIME_MILLIS = 10000;

	private static final Log logger;

	static {
		logger = new Log4JLogger(Utility
				.getLoggerName(PublishEventSampleServiceThread.class));
	}

	private final AxisService service;

	private final ServiceClient serviceClient;

	private final Random random;

	public PublishEventSampleServiceThread(AxisService service)
			throws AxisFault {
		this.service = service;
		this.serviceClient = this.getServiceClient();
		this.random = new Random();
	}

	private ServiceClient getServiceClient() throws AxisFault {
		ServiceClient serviceClient = new ServiceClient();
		serviceClient.getOptions().setAction(
				PublishEventSampleServiceCommons.NOTIFY_EVENT_ACTION_ID);
		return serviceClient;
	}

	@SuppressWarnings("unchecked")
	public void run() {
		logger.info(PublishEventSampleServiceThread.class + " IS RUNNING");
		while (true) {
			List<String> consumerList = (List<String>) service
					.getParameterValue(PublishEventSampleServiceCommons.CONSUMER_LIST);
			for (String consumer : consumerList) {
				notifyClient(consumer);
				try {
					Thread.sleep(SLEEP_TIME_MILLIS);
				} catch (InterruptedException ex) {
					logger.error("Exception occurred while thread sleep", ex);
				}
			}
		}
	}

	private void notifyClient(String endPointReference) {
		try {
			this.serviceClient.getOptions().setTo(
					new EndpointReference(endPointReference));
			this.serviceClient.sendRobust(createMessagePayLoad());
		} catch (AxisFault axisFault) {
		}
	}

	private OMElement createMessagePayLoad() {
		long randomValue = this.random.nextLong();
		OMFactory factory = OMAbstractFactory.getOMFactory();
		OMNamespace namespace = factory.createOMNamespace(
				Service.ConsumeEventSampleService.getNamespaceUri(),
				Service.NAMESPACE_ALIAS);
		OMElement method = factory.createOMElement(
				PublishEventSampleServiceCommons.NOTIFY_EVENT_REQUEST,
				namespace);
		OMElement value = factory.createOMElement(Service.INPUT_PARAMETER,
				namespace);
		value.setText(Long.toString(randomValue));
		method.addChild(value);
		return method;
	}
}