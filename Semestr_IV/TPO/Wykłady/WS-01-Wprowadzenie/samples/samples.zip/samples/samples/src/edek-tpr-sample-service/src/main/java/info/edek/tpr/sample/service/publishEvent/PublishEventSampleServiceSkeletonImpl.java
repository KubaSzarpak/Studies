package info.edek.tpr.sample.service.publishEvent;

import info.edek.tpr.sample.service.util.Utility;

import java.util.List;

import org.apache.axis2.context.MessageContext;
import org.apache.axis2.description.AxisService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.impl.Log4JLogger;

public class PublishEventSampleServiceSkeletonImpl implements
		PublishEventSampleServiceSkeletonInterface {

	private final static Log logger;

	static {
		logger = new Log4JLogger(Utility
				.getLoggerName(PublishEventSampleServiceSkeletonImpl.class));
	}

	public void subscribeEvent(SubscribeEventRequest request) {
		String consumerUri = request.getIn();
		List<String> consumerList = this.getConsumerList();
		if (!consumerList.contains(consumerUri)) {
			consumerList.add(consumerUri);
			logger
					.info("CONSUMER LIST HAS BEEN SUCCESSFULLY APPENDED WITH URI: "
							+ consumerUri);
		}
	}

	@SuppressWarnings("unchecked")
	private List<String> getConsumerList() {
		MessageContext msgCtx = MessageContext.getCurrentMessageContext();
		AxisService service = msgCtx.getAxisService();
		List<String> consumerList = (List<String>) service
				.getParameterValue(PublishEventSampleServiceCommons.CONSUMER_LIST);
		return consumerList;
	}
}