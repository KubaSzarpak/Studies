package info.edek.tpr.sample.service.publishEvent;

public class PublishEventSampleServiceCommons {

	public static final String CONSUMER_LIST = "ConsumerList";

	public static final String NOTIFY_EVENT_ACTION_ID = "urn:NotifyEvent";

	public static final String NOTIFY_EVENT_REQUEST = "NotifyEventRequest";

	public static final String NAMESPACE_TPR = "http://edek.info/tpr/EventSampleService/";

	public static final String NAMESPACE_PREFIX_TPR = "tpr";
}