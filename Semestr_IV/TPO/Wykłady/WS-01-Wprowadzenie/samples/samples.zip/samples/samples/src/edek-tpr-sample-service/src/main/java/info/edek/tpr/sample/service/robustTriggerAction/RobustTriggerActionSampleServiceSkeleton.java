
/**
 * RobustTriggerActionSampleServiceSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:00 EDT)
 */
    package info.edek.tpr.sample.service.robustTriggerAction;
    /**
     *  RobustTriggerActionSampleServiceSkeleton java skeleton for the axisService
     */
    public class RobustTriggerActionSampleServiceSkeleton implements RobustTriggerActionSampleServiceSkeletonInterface{
        
         
        /**
         * Auto generated method signature
         * 
                                     * @param robustTriggerActionRequest0
         */
        
                 public void robustTriggerAction
                  (
                  info.edek.tpr.sample.service.robustTriggerAction.RobustTriggerActionRequest robustTriggerActionRequest0
                  )
            {
                //TODO : fill this with the necessary business logic
                
        }
     
    }
    