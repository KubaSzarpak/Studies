package info.edek.tpr.sample.client.main;

import info.edek.tpr.sample.client.simple.SampleServiceStub;
import info.edek.tpr.sample.client.simple.SampleServiceStub.EchoMessageRequest;
import info.edek.tpr.sample.client.simple.SampleServiceStub.EchoMessageResponse;
import info.edek.tpr.sample.client.util.Service;
import info.edek.tpr.sample.client.util.Utility;

import org.apache.axis2.AxisFault;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.impl.Log4JLogger;

public final class MainSimpleCli {

	private static final Log logger;

	static {
		logger = new Log4JLogger(Utility.getLoggerName(MainSimpleCli.class));
	}

	private static EchoMessageRequest getEchoMessageRequest() {
		EchoMessageRequest request = new EchoMessageRequest();
		request.setIn(Utility.getMessage());
		return request;
	}

	private static SampleServiceStub getSampleServiceStub() throws AxisFault {
		return new SampleServiceStub(Service.SampleService.getServiceUri());
	}

	public static void main(String... args) {
		try {
			logger.info("<application started>");
			SampleServiceStub sampleServiceStub = getSampleServiceStub();
			EchoMessageRequest request = getEchoMessageRequest();
			EchoMessageResponse response = sampleServiceStub
					.echoMessage(request);
			logger.info("<SUCCESS> response: " + response.getOut());
			logger.info("<aplication accomplished>");
		} catch (Throwable ex) {
			logger.fatal("execution fault", ex);
		}
	}
}