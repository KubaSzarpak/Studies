
/**
 * TriggerActionSampleServiceSkeletonInterface.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:00 EDT)
 */
    package info.edek.tpr.sample.service.triggerAction;
    /**
     *  TriggerActionSampleServiceSkeletonInterface java skeleton interface for the axisService
     */
    public interface TriggerActionSampleServiceSkeletonInterface {
     
         
        /**
         * Auto generated method signature
         * 
                                    * @param triggerActionRequest
         */

        
                public void triggerAction
                (
                  info.edek.tpr.sample.service.triggerAction.TriggerActionRequest triggerActionRequest
                 )
            ;
        
         }
    