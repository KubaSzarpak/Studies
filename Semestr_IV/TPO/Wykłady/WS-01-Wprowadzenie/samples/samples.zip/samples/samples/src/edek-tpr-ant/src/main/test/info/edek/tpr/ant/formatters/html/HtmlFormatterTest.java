package info.edek.tpr.ant.formatters.html;

import info.edek.tpr.ant.formatters.html.HtmlFormatter;

import java.io.File;

import org.junit.Test;

public class HtmlFormatterTest {

	private static final String test01 = "-test01";
	private static final String test02 = "-test02";
	private static final String suffix = ".html";

	private static final File inputFile = new File("input/SampleService.wsdl");
	private static final File outputFile1 = new File(inputFile.getPath()
			+ test01 + suffix);

	public HtmlFormatterTest() {
	}

	@Test
	public void TestInputOutput() throws Throwable {
		HtmlFormatter formatter = new HtmlFormatter();
		formatter.setInput(inputFile);
		formatter.setOutput(outputFile1);
		formatter.execute();
	}

	@Test
	public void TestInputSuffix() throws Throwable {
		HtmlFormatter formatter = new HtmlFormatter();
		formatter.setInput(inputFile);
		formatter.setSuffix(test02 + suffix);
		formatter.execute();
	}
}