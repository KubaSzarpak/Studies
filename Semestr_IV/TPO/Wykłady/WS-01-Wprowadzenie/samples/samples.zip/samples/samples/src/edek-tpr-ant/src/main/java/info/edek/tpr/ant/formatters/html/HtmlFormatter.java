package info.edek.tpr.ant.formatters.html;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.regexp.RE;

final class HtmlFormatter {

	private static final String PATTERN_TAG_BEGIN = "<";

	private static final String SUBSTITUTE_TAG_BEGIN = "&lt;";

	private static final String PATTERN_TAG_END = ">";

	private static final String SUBSTITUTE_TAG_END = "&gt;";

	private static final int BUFFER_LENGTH = 4096;

	private final RE regexTagBegin;

	private final RE regexTagEnd;

	private File input;

	private File output;

	private String suffix;

	HtmlFormatter() {
		this.regexTagBegin = new RE(PATTERN_TAG_BEGIN);
		this.regexTagEnd = new RE(PATTERN_TAG_END);
	}

	private File getInput() {
		return this.input;
	}

	private File getOutput() {
		if (this.output == null) {
			this.output = new File(this.getInput().getPath() + this.getSuffix());
		}
		return this.output;
	}

	private String getSuffix() {
		return this.suffix;
	}

	void setInput(File input) {
		this.input = input;
	}

	void setOutput(File output) {
		this.output = output;
	}

	void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	private byte[] formatInputBuffer(byte[] inputBuffer, int length) {
		String inputString = new String(inputBuffer, 0, length);
		String outputString = this.regexTagBegin.subst(inputString,
				SUBSTITUTE_TAG_BEGIN);
		outputString = this.regexTagEnd.subst(outputString, SUBSTITUTE_TAG_END);
		return outputString.getBytes();
	}

	void execute() throws IOException {
		FileInputStream input = new FileInputStream(this.getInput());
		FileOutputStream output = new FileOutputStream(this.getOutput());
		byte[] buffer = new byte[BUFFER_LENGTH];
		final int EOF = 0;
		for (int bytesRead = EOF; (bytesRead = input.read(buffer)) > EOF;) {
			output.write(formatInputBuffer(buffer, bytesRead));
		}
		input.close();
		output.close();
	}
}