
/**
 * ConsumeEventSampleServiceSkeletonInterface.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:00 EDT)
 */
    package info.edek.tpr.sample.service.consumeEvent;
    /**
     *  ConsumeEventSampleServiceSkeletonInterface java skeleton interface for the axisService
     */
    public interface ConsumeEventSampleServiceSkeletonInterface {
     
         
        /**
         * Auto generated method signature
         * 
                                    * @param notifyEventRequest
         */

        
                public void notifyEvent
                (
                  info.edek.tpr.sample.service.consumeEvent.NotifyEventRequest notifyEventRequest
                 )
            ;
        
         }
    