package info.edek.tpr.sample.service.robustTriggerAction;

import java.rmi.RemoteException;

public class RobustTriggerActionException extends RemoteException {

	private static final long serialVersionUID = 8687281941590919413L;

	public RobustTriggerActionException(String message) {
		super(message);
	}
}