
/**
 * TimeoutSampleServiceSkeletonInterface.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:00 EDT)
 */
    package info.edek.tpr.sample.service.timeout;
    /**
     *  TimeoutSampleServiceSkeletonInterface java skeleton interface for the axisService
     */
    public interface TimeoutSampleServiceSkeletonInterface {
     
         
        /**
         * Auto generated method signature
         * 
                                    * @param timeoutEchoMessageRequest
         */

        
                public info.edek.tpr.sample.service.timeout.TimeoutEchoMessageResponse timeoutEchoMessage
                (
                  info.edek.tpr.sample.service.timeout.TimeoutEchoMessageRequest timeoutEchoMessageRequest
                 )
            ;
        
         }
    