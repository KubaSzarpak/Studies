package info.edek.tpr.ant.formatters.html;

import java.io.File;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;

public final class HtmlFormatterTask extends Task {

	private final HtmlFormatter formatterImpl;

	public HtmlFormatterTask() {
		this.formatterImpl = new HtmlFormatter();
	}

	public void setInput(File input) {
		this.formatterImpl.setInput(input);
	}

	public void setOutput(File output) {
		this.formatterImpl.setOutput(output);
	}

	public void setSuffix(String suffix) {
		this.formatterImpl.setSuffix(suffix);
	}

	public void execute() throws BuildException {
		try {
			this.formatterImpl.execute();
		} catch (Throwable ex) {
			throw new BuildException(
					"exception occurred while formatting tagged input", ex);
		}
	}
}