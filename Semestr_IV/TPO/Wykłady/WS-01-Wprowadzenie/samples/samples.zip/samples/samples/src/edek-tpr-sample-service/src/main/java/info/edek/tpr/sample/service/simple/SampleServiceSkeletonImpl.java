package info.edek.tpr.sample.service.simple;

import info.edek.tpr.sample.service.timeout.TimeoutSampleServiceSkeletonImpl;
import info.edek.tpr.sample.service.util.Utility;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.impl.Log4JLogger;

public final class SampleServiceSkeletonImpl implements
		SampleServiceSkeletonInterface {

	private static final Log logger;

	static {
		logger = new Log4JLogger(Utility
				.getLoggerName(TimeoutSampleServiceSkeletonImpl.class));
	}

	public EchoMessageResponse echoMessage(EchoMessageRequest request) {
		EchoMessageResponse response = new EchoMessageResponse();
		response.localOut = Utility.getResponseMessage(this.getClass(),
				request.localIn);
		return response;
	}
}