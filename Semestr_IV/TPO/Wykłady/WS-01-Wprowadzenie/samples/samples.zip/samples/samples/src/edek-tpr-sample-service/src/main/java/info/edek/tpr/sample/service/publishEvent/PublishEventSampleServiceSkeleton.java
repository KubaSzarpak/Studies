
/**
 * PublishEventSampleServiceSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:00 EDT)
 */
    package info.edek.tpr.sample.service.publishEvent;
    /**
     *  PublishEventSampleServiceSkeleton java skeleton for the axisService
     */
    public class PublishEventSampleServiceSkeleton implements PublishEventSampleServiceSkeletonInterface{
        
         
        /**
         * Auto generated method signature
         * 
                                     * @param subscribeEventRequest0
         */
        
                 public void subscribeEvent
                  (
                  info.edek.tpr.sample.service.publishEvent.SubscribeEventRequest subscribeEventRequest0
                  )
            {
                //TODO : fill this with the necessary business logic
                
        }
     
    }
    