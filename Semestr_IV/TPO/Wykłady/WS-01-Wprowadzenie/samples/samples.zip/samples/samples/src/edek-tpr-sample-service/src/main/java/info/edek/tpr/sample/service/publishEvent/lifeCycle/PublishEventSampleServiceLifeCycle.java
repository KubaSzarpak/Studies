package info.edek.tpr.sample.service.publishEvent.lifeCycle;

import info.edek.tpr.sample.service.publishEvent.PublishEventSampleServiceCommons;
import info.edek.tpr.sample.service.util.Utility;

import java.util.ArrayList;
import java.util.List;

import org.apache.axis2.AxisFault;
import org.apache.axis2.context.ConfigurationContext;
import org.apache.axis2.description.AxisService;
import org.apache.axis2.description.Parameter;
import org.apache.axis2.engine.ServiceLifeCycle;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.impl.Log4JLogger;

public class PublishEventSampleServiceLifeCycle implements ServiceLifeCycle {

	private static final Log logger;

	static {
		logger = new Log4JLogger(Utility
				.getLoggerName(PublishEventSampleServiceLifeCycle.class));
	}

	private PublishEventSampleServiceThread serviceThread;

	public void startUp(ConfigurationContext config, AxisService service) {
		try {
			this.createConsumerListParameter(service);
			this.serviceThread = new PublishEventSampleServiceThread(service);
			this.serviceThread.start();
			logger.info(PublishEventSampleServiceLifeCycle.class
					+ " HAS BEEN STARTED SUCCESSFULLY");
		} catch (AxisFault ex) {
			logger.error("Exception occurred while starting up "
					+ PublishEventSampleServiceLifeCycle.class, ex);
		}
	}

	private void createConsumerListParameter(AxisService service) {
		List<String> consumerList = new ArrayList<String>();
		Parameter userParameter = new Parameter();
		userParameter.setName(PublishEventSampleServiceCommons.CONSUMER_LIST);
		userParameter.setValue(consumerList);
		try {
			service.addParameter(userParameter);
		} catch (AxisFault ex) {
			logger.error("Exception occurred while creating "
					+ PublishEventSampleServiceCommons.CONSUMER_LIST
					+ " service parameter", ex);
		}
	}

	public void shutDown(ConfigurationContext configctx, AxisService service) {
		logger.info(PublishEventSampleServiceLifeCycle.class
				+ " HAS BEEN SHUT DOWN SUCCESSFULLY");
	}
}