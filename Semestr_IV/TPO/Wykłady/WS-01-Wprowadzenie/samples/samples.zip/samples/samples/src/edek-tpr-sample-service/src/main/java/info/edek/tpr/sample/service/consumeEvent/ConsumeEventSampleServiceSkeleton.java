
/**
 * ConsumeEventSampleServiceSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:00 EDT)
 */
    package info.edek.tpr.sample.service.consumeEvent;
    /**
     *  ConsumeEventSampleServiceSkeleton java skeleton for the axisService
     */
    public class ConsumeEventSampleServiceSkeleton implements ConsumeEventSampleServiceSkeletonInterface{
        
         
        /**
         * Auto generated method signature
         * 
                                     * @param notifyEventRequest0
         */
        
                 public void notifyEvent
                  (
                  info.edek.tpr.sample.service.consumeEvent.NotifyEventRequest notifyEventRequest0
                  )
            {
                //TODO : fill this with the necessary business logic
                
        }
     
    }
    