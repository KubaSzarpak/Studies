package info.edek.tpr.sample.client.main;

import info.edek.tpr.sample.client.consumeEvent.ConsumeEventSampleServiceStub;
import info.edek.tpr.sample.client.consumeEvent.ConsumeEventSampleServiceStub.NotifyEventRequest;
import info.edek.tpr.sample.client.publishEvent.PublishEventSampleServiceStub;
import info.edek.tpr.sample.client.publishEvent.PublishEventSampleServiceStub.SubscribeEventRequest;
import info.edek.tpr.sample.client.util.Service;
import info.edek.tpr.sample.client.util.Utility;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SpringLayout;

import org.apache.axis2.AxisFault;
import org.apache.axis2.client.ServiceClient;

public class MainPublishConsumeEventGui extends JFrame implements
		ActionListener {

	private static final long serialVersionUID = 465320630720463494L;

	private static final int DEFAULT_PADDING = 5;
	private static final int DEFAULT_WIDTH = 500;
	private static final int DEFAULT_HEIGHT = 200;

	private PublishEventSampleServiceStub publishEventServiceStub;

	private ConsumeEventSampleServiceStub consumeEventServiceStub;

	private JLabel lblPublishEventSampleService;

	private JLabel lblConsumeEventSampleService;

	private JButton btnSubscribeEvent;

	private JButton btnNotifyEvent;

	private MainPublishConsumeEventGui() {
		try {
			this.publishEventServiceStub = getPublishEventSampleServiceStub();
			this.consumeEventServiceStub = getConsumeEventSampleServiceStub();
			this.lblPublishEventSampleService = new JLabel(
					Service.PublishEventSampleService.getServiceUri());
			this.lblConsumeEventSampleService = new JLabel(
					Service.ConsumeEventSampleService.getNamespaceUri());
			this.btnSubscribeEvent = new JButton("SubscribeEvent");
			this.btnSubscribeEvent.addActionListener(this);
			this.btnNotifyEvent = new JButton("NotifyEvent");
			this.btnNotifyEvent.addActionListener(this);
			Container container = this.getContentPane();
			Box box = new Box(BoxLayout.Y_AXIS);
			Container pnlLabels = getLabelsPanel();
			Container pnlButtons = getButtonsPanel();
			box.add(pnlLabels);
			box.add(pnlButtons);
			container.add(box);
			this.pack();
			this.setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
			this.setVisible(true);
		} catch (AxisFault ex) {
			this.showMessageBox(ex);
		}
	}

	private Container getLabelsPanel() {
		JPanel container = new JPanel();
		SpringLayout layout = new SpringLayout();
		container.setLayout(layout);
		container.add(this.lblPublishEventSampleService);
		container.add(this.lblConsumeEventSampleService);
		layout.putConstraint(SpringLayout.WEST,
				this.lblPublishEventSampleService, DEFAULT_PADDING,
				SpringLayout.WEST, container);
		layout.putConstraint(SpringLayout.NORTH,
				this.lblPublishEventSampleService, DEFAULT_PADDING,
				SpringLayout.NORTH, container);
		layout.putConstraint(SpringLayout.EAST,
				this.lblPublishEventSampleService, -DEFAULT_PADDING,
				SpringLayout.EAST, container);

		layout.putConstraint(SpringLayout.WEST,
				this.lblConsumeEventSampleService, DEFAULT_PADDING,
				SpringLayout.WEST, container);
		layout.putConstraint(SpringLayout.NORTH,
				this.lblConsumeEventSampleService, DEFAULT_PADDING,
				SpringLayout.SOUTH, this.lblPublishEventSampleService);
		layout.putConstraint(SpringLayout.EAST,
				this.lblConsumeEventSampleService, -DEFAULT_PADDING,
				SpringLayout.EAST, container);
		layout.putConstraint(SpringLayout.SOUTH,
				this.lblConsumeEventSampleService, -DEFAULT_PADDING,
				SpringLayout.SOUTH, container);
		return container;
	}

	private Container getButtonsPanel() {
		JPanel container = new JPanel();
		SpringLayout layButtons = new SpringLayout();
		container.add(this.btnSubscribeEvent);
		container.add(this.btnNotifyEvent);
		layButtons.putConstraint(SpringLayout.WEST, this.btnSubscribeEvent,
				DEFAULT_PADDING, SpringLayout.WEST, container);
		layButtons.putConstraint(SpringLayout.NORTH, this.btnSubscribeEvent,
				DEFAULT_PADDING, SpringLayout.NORTH, container);
		layButtons.putConstraint(SpringLayout.SOUTH, this.btnSubscribeEvent,
				-DEFAULT_PADDING, SpringLayout.SOUTH, container);

		layButtons.putConstraint(SpringLayout.WEST, this.btnNotifyEvent,
				DEFAULT_PADDING, SpringLayout.EAST, this.btnSubscribeEvent);
		layButtons.putConstraint(SpringLayout.NORTH, this.btnNotifyEvent,
				DEFAULT_PADDING, SpringLayout.NORTH, container);
		layButtons.putConstraint(SpringLayout.EAST, this.btnNotifyEvent,
				-DEFAULT_PADDING, SpringLayout.EAST, container);
		layButtons.putConstraint(SpringLayout.SOUTH, this.btnSubscribeEvent,
				-DEFAULT_PADDING, SpringLayout.SOUTH, container);
		return container;
	}

	private static SubscribeEventRequest getSubscribeEventRequest() {
		SubscribeEventRequest request = new SubscribeEventRequest();
		request.setIn(Service.ConsumeEventSampleService.getServiceUri());
		return request;
	}

	private static NotifyEventRequest getNotifyEventRequest() {
		NotifyEventRequest request = new NotifyEventRequest();
		request.setIn(Utility.getMessage());
		return request;
	}

	private static PublishEventSampleServiceStub getPublishEventSampleServiceStub()
			throws AxisFault {
		return new PublishEventSampleServiceStub(
				Service.PublishEventSampleService.getServiceUri());
	}

	private static ConsumeEventSampleServiceStub getConsumeEventSampleServiceStub()
			throws AxisFault {
		return new ConsumeEventSampleServiceStub(
				Service.ConsumeEventSampleService.getServiceUri());
	}

	private void showMessageBox(Throwable ex) {
		JOptionPane.showMessageDialog(this, ex);
	}

	public void actionPerformed(ActionEvent e) {
		try {
			if (e.getSource() == this.btnSubscribeEvent) {
				final String ACTION_SUBSCRIBE = "urn:SubscribeEvent";
				SubscribeEventRequest request = getSubscribeEventRequest();
				ServiceClient client = this.publishEventServiceStub
						._getServiceClient();
				client.getOptions().setAction(ACTION_SUBSCRIBE);
				this.publishEventServiceStub.subscribeEvent(request);
			} else if (e.getSource() == this.btnNotifyEvent) {
				NotifyEventRequest request = getNotifyEventRequest();
				this.consumeEventServiceStub.notifyEvent(request);
			}
		} catch (Throwable ex) {
			this.showMessageBox(ex);
		}
	}

	public static void main(String... args) {
		new MainPublishConsumeEventGui();
	}
}