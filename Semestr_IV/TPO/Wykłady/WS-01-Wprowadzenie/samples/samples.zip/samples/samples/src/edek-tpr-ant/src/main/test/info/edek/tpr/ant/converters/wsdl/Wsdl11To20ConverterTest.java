package info.edek.tpr.ant.converters.wsdl;

import java.io.File;

import org.junit.Test;

public class Wsdl11To20ConverterTest {

	private static final File inputFile = new File("input/SampleService.wsdl");
	private static final File outputFile = new File(
			"input/SampleService-2.0.wsdl");

	public Wsdl11To20ConverterTest() {
	}

	@Test
	public void TestInputOutput() throws Throwable {
		Wsdl11To20Converter converter = new Wsdl11To20Converter();
		converter.setInput(inputFile);
		converter.setOutput(outputFile);
		converter.execute();
	}
}