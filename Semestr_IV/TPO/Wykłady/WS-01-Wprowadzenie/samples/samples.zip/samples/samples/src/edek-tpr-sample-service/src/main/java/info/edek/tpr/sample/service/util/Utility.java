package info.edek.tpr.sample.service.util;

public final class Utility {

	private Utility() {
	}

	private static final String RESPONSE_PREFIX = " RESPONSE: ";

	private static final String REQUEST_PREFIX = " REQUEST: [";

	private static final String REQUEST_RECEIVED_SUFFX = "] HAS BEEN RECEIVED";

	private static String getClassName(Class<?> c) {
		return c.getCanonicalName();
	}

	public static String getResponseMessage(Class<?> c, String message) {
		return getClassName(c) + RESPONSE_PREFIX + message;
	}

	public static String getLoggerName(Class<?> c) {
		return getClassName(c);
	}

	public static String getRequestReceivedLog(Class<?> c, String message) {
		return getClassName(c) + REQUEST_PREFIX + message
				+ REQUEST_RECEIVED_SUFFX;
	}
}