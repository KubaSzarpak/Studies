package info.edek.tpr.sample.service.triggerAction;

import info.edek.tpr.sample.service.util.Utility;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.impl.Log4JLogger;

public class TriggerActionSampleServiceSkeletonImpl implements
		TriggerActionSampleServiceSkeletonInterface {

	private static final Log logger;

	static {
		logger = new Log4JLogger(Utility
				.getLoggerName(TriggerActionSampleServiceSkeletonImpl.class));
	}

	public void triggerAction(TriggerActionRequest request) {
		String message = request.getIn();
		logger.info(Utility.getRequestReceivedLog(
				TriggerActionSampleServiceSkeletonImpl.class, message));
	}
}