package info.edek.tpr.sample.client.main;

import info.edek.tpr.sample.client.simple.SampleServiceStub;
import info.edek.tpr.sample.client.simple.SampleServiceStub.EchoMessageRequest;
import info.edek.tpr.sample.client.simple.SampleServiceStub.EchoMessageResponse;
import info.edek.tpr.sample.client.util.Service;
import info.edek.tpr.sample.client.util.Utility;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SpringLayout;

import org.apache.axis2.AxisFault;

public class MainSimpleGui extends JFrame implements ActionListener {

	private static final long serialVersionUID = 465320630720463494L;

	private SampleServiceStub sampleServiceStub;

	private JButton btnEchoMessage;

	private JTextArea txtOutput;

	private JScrollPane scroll;

	private MainSimpleGui() {
		try {
			this.sampleServiceStub = getSampleServiceStub();
			this.btnEchoMessage = new JButton("EchoMessage");
			this.btnEchoMessage.addActionListener(this);
			this.txtOutput = new JTextArea(20, 0);
			this.scroll = new JScrollPane(this.txtOutput);
			Container content = this.getContentPane();
			SpringLayout layout = new SpringLayout();
			content.setLayout(layout);
			content.add(this.scroll);
			content.add(this.btnEchoMessage);
			final int DEFAULT_PADDING = 5;
			final int DEFAULT_WIDTH = 640;
			final int DEFAULT_HEIGHT = 480;
			layout.putConstraint(SpringLayout.WEST, this.scroll,
					DEFAULT_PADDING, SpringLayout.WEST, content);
			layout.putConstraint(SpringLayout.NORTH, this.scroll,
					DEFAULT_PADDING, SpringLayout.NORTH, content);
			layout.putConstraint(SpringLayout.EAST, this.scroll,
					-DEFAULT_PADDING, SpringLayout.EAST, content);
			layout.putConstraint(SpringLayout.WEST, this.btnEchoMessage,
					DEFAULT_PADDING, SpringLayout.WEST, content);
			layout.putConstraint(SpringLayout.NORTH, this.btnEchoMessage,
					DEFAULT_PADDING, SpringLayout.SOUTH, this.scroll);
			layout.putConstraint(SpringLayout.SOUTH, this.btnEchoMessage,
					-DEFAULT_PADDING, SpringLayout.SOUTH, content);
			layout.putConstraint(SpringLayout.EAST, this.btnEchoMessage,
					-DEFAULT_PADDING, SpringLayout.EAST, content);
			this.pack();
			this.setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
			this.setVisible(true);
		} catch (AxisFault ex) {
			this.showMessageBox(ex);
		}
	}

	private static EchoMessageRequest getEchoMessageRequest() {
		EchoMessageRequest request = new EchoMessageRequest();
		request.setIn(Utility.getMessage());
		return request;
	}

	private static SampleServiceStub getSampleServiceStub() throws AxisFault {
		return new SampleServiceStub(Service.SampleService.getServiceUri());
	}

	private void showMessageBox(Throwable ex) {
		JOptionPane.showMessageDialog(this, ex);
	}

	public void actionPerformed(ActionEvent e) {
		try {
			EchoMessageRequest request = getEchoMessageRequest();
			EchoMessageResponse response = this.sampleServiceStub
					.echoMessage(request);
			String output = this.txtOutput.getText() + "\n" + response.getOut();
			this.txtOutput.setText(output);
		} catch (Throwable ex) {
			this.showMessageBox(ex);
		}
	}

	public static void main(String... args) {
		new MainSimpleGui();
	}
}