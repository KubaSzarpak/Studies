package info.edek.tpr.sample.client.main;

import info.edek.tpr.sample.client.simple.SampleServiceStub;
import info.edek.tpr.sample.client.simple.SampleServiceStub.EchoMessageRequest;
import info.edek.tpr.sample.client.simple.SampleServiceStub.EchoMessageResponse;
import info.edek.tpr.sample.client.timeout.TimeoutSampleServiceStub;
import info.edek.tpr.sample.client.timeout.TimeoutSampleServiceStub.TimeoutEchoMessageRequest;
import info.edek.tpr.sample.client.timeout.TimeoutSampleServiceStub.TimeoutEchoMessageResponse;
import info.edek.tpr.sample.client.util.Service;
import info.edek.tpr.sample.client.util.Utility;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SpringLayout;

import org.apache.axis2.AxisFault;

public class MainTimeoutGuiBlocking extends JFrame implements ActionListener {

	private static final long serialVersionUID = 465320630720463494L;

	private SampleServiceStub sampleServiceStub;

	private TimeoutSampleServiceStub timeoutSampleServiceStub;

	private JButton btnEchoMessage;

	private JButton btnTimeoutEchoMessage;

	private JTextArea txtOutput;

	private JScrollPane scroll;

	private MainTimeoutGuiBlocking() {
		try {
			this.sampleServiceStub = getSampleServiceStub();
			this.timeoutSampleServiceStub = getTimeoutSampleServiceStub();
			this.btnEchoMessage = new JButton("EchoMessage");
			this.btnEchoMessage.addActionListener(this);
			this.btnTimeoutEchoMessage = new JButton("TimeoutEchoMessage");
			this.btnTimeoutEchoMessage.addActionListener(this);
			this.txtOutput = new JTextArea(20, 0);
			this.scroll = new JScrollPane(this.txtOutput);
			Container content = this.getContentPane();
			SpringLayout layout = new SpringLayout();
			content.setLayout(layout);
			content.add(this.scroll);
			content.add(this.btnEchoMessage);
			content.add(this.btnTimeoutEchoMessage);
			final int DEFAULT_PADDING = 5;
			final int DEFAULT_WIDTH = 640;
			final int DEFAULT_HEIGHT = 480;
			// layout for scroll
			layout.putConstraint(SpringLayout.WEST, this.scroll,
					DEFAULT_PADDING, SpringLayout.WEST, content);
			layout.putConstraint(SpringLayout.NORTH, this.scroll,
					DEFAULT_PADDING, SpringLayout.NORTH, content);
			layout.putConstraint(SpringLayout.EAST, this.scroll,
					-DEFAULT_PADDING, SpringLayout.EAST, content);
			// layout for btnEchoMessage
			layout.putConstraint(SpringLayout.WEST, this.btnEchoMessage,
					DEFAULT_PADDING, SpringLayout.WEST, content);
			layout.putConstraint(SpringLayout.NORTH, this.btnEchoMessage,
					DEFAULT_PADDING, SpringLayout.SOUTH, this.scroll);
			layout.putConstraint(SpringLayout.SOUTH, this.btnEchoMessage,
					-DEFAULT_PADDING, SpringLayout.SOUTH, content);
			layout.putConstraint(SpringLayout.EAST, this.btnEchoMessage,
					-DEFAULT_PADDING, SpringLayout.VERTICAL_CENTER, content);
			// layout for btnTimeoutEchoMessage
			layout.putConstraint(SpringLayout.WEST, this.btnTimeoutEchoMessage,
					DEFAULT_PADDING, SpringLayout.VERTICAL_CENTER, content);
			layout.putConstraint(SpringLayout.NORTH,
					this.btnTimeoutEchoMessage, DEFAULT_PADDING,
					SpringLayout.SOUTH, this.scroll);
			layout.putConstraint(SpringLayout.SOUTH,
					this.btnTimeoutEchoMessage, -DEFAULT_PADDING,
					SpringLayout.SOUTH, content);
			layout.putConstraint(SpringLayout.EAST, this.btnTimeoutEchoMessage,
					-DEFAULT_PADDING, SpringLayout.EAST, content);
			this.pack();
			this.setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
			this.setVisible(true);
		} catch (AxisFault ex) {
			this.showMessageBox(ex);
		}
	}

	private static EchoMessageRequest getEchoMessageRequest() {
		EchoMessageRequest request = new EchoMessageRequest();
		request.setIn(Utility.getMessage());
		return request;
	}

	private static TimeoutEchoMessageRequest getTimeoutEchoMessageRequest() {
		TimeoutEchoMessageRequest request = new TimeoutEchoMessageRequest();
		request.setIn(Utility.getMessage());
		return request;
	}

	private static SampleServiceStub getSampleServiceStub() throws AxisFault {
		return new SampleServiceStub(Service.SampleService.getServiceUri());
	}

	private static TimeoutSampleServiceStub getTimeoutSampleServiceStub()
			throws AxisFault {
		return new TimeoutSampleServiceStub(Service.TimeoutSampleService
				.getServiceUri());
	}

	private void showMessageBox(Throwable ex) {
		JOptionPane.showMessageDialog(this, ex);
	}

	public void actionPerformed(ActionEvent ev) {
		try {
			String output = null;
			if (ev.getSource() == this.btnEchoMessage) {
				EchoMessageRequest request = getEchoMessageRequest();
				EchoMessageResponse response = this.sampleServiceStub
						.echoMessage(request);
				output = this.txtOutput.getText() + "\n" + response.getOut();
			} else if (ev.getSource() == this.btnTimeoutEchoMessage) {
				TimeoutEchoMessageRequest request = getTimeoutEchoMessageRequest();
				TimeoutEchoMessageResponse response = this.timeoutSampleServiceStub
						.timeoutEchoMessage(request);
				output = this.txtOutput.getText() + "\n" + response.getOut();
			}
			if (output != null) {
				this.txtOutput.setText(output);
			}
		} catch (Throwable ex) {
			this.showMessageBox(ex);
		}
	}

	public static void main(String... args) {
		new MainTimeoutGuiBlocking();
	}
}