
/**
 * PublishEventSampleServiceSkeletonInterface.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:00 EDT)
 */
    package info.edek.tpr.sample.service.publishEvent;
    /**
     *  PublishEventSampleServiceSkeletonInterface java skeleton interface for the axisService
     */
    public interface PublishEventSampleServiceSkeletonInterface {
     
         
        /**
         * Auto generated method signature
         * 
                                    * @param subscribeEventRequest
         */

        
                public void subscribeEvent
                (
                  info.edek.tpr.sample.service.publishEvent.SubscribeEventRequest subscribeEventRequest
                 )
            ;
        
         }
    