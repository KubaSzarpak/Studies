package info.edek.tpr.sample.client.util;

public enum Service {

	SampleService(""), TimeoutSampleService("Timeout"), TriggerActionSampleService(
			"TriggerAction"), PublishEventSampleService("PublishEvent"), ConsumeEventSampleService(
			"ConsumeEvent"), DualClientSampleService("DualClient"), RobustTriggerActionSampleService(
			"RobustTriggerAction");

	private static final String SAMPLE_SERVICE_SUFFIX = "SampleService";

	private static final String SERVICE_URI_PREFIX = "http://localhost:8081/axis2/services/";

	private static final String NAMESPACE_PREFIX = "http://edek.info/tpr/";

	public static final String NAMESPACE_ALIAS = "tpr";

	public static final String INPUT_PARAMETER = "in";

	private final String uri;

	private final String namespaceUri;

	private Service(String prefix) {
		String serviceName = prefix + SAMPLE_SERVICE_SUFFIX;
		this.uri = SERVICE_URI_PREFIX + serviceName;
		this.namespaceUri = NAMESPACE_PREFIX + serviceName + "/";
	}

	public String getServiceUri() {
		return this.uri;
	}

	public String getNamespaceUri() {
		return this.namespaceUri;
	}

	public String toString() {
		return this.getServiceUri();
	}
}