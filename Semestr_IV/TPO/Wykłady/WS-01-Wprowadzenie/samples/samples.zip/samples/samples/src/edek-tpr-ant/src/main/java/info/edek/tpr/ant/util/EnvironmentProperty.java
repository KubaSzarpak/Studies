package info.edek.tpr.ant.util;

public enum EnvironmentProperty {

	TemporaryDirectory("java.io.tmpdir");

	private final String key;

	private EnvironmentProperty(String key) {
		this.key = key;
	}

	public String getKey() {
		return this.key;
	}

	public String getValue() {
		return System.getProperty(this.getKey());
	}
}