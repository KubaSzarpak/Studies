package info.edek.tpr.sample.service.robustTriggerAction;

public class RobustTriggerActionSampleServiceSkeletonImpl implements
		RobustTriggerActionSampleServiceSkeletonInterface {

	public void robustTriggerAction(RobustTriggerActionRequest request)
			throws RobustTriggerActionException {
		throw new RobustTriggerActionException("REQUEST PROCESSING FAILED: "
				+ request.getIn());
	}
}