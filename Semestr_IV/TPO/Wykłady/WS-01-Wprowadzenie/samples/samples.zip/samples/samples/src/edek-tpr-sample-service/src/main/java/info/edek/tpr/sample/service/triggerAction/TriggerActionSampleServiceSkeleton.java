
/**
 * TriggerActionSampleServiceSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:00 EDT)
 */
    package info.edek.tpr.sample.service.triggerAction;
    /**
     *  TriggerActionSampleServiceSkeleton java skeleton for the axisService
     */
    public class TriggerActionSampleServiceSkeleton implements TriggerActionSampleServiceSkeletonInterface{
        
         
        /**
         * Auto generated method signature
         * 
                                     * @param triggerActionRequest0
         */
        
                 public void triggerAction
                  (
                  info.edek.tpr.sample.service.triggerAction.TriggerActionRequest triggerActionRequest0
                  )
            {
                //TODO : fill this with the necessary business logic
                
        }
     
    }
    