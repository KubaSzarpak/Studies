package info.edek.tpr.ant.converters.wsdl;

import info.edek.tpr.ant.util.EnvironmentProperty;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.wsdl.WSDLException;

import org.apache.woden.tool.converter.Convert;

public final class Wsdl11To20Converter {

	private static final String suffixWsdl = ".wsdl";
	private static final String suffixTemporaryWsdl2 = ".wsdl2";

	private final Convert converter;

	private File input;

	private File output;

	private String targetNameSpace;

	Wsdl11To20Converter() {
		this.converter = new Convert();
	}

	private File getOutput() {
		return this.output;
	}

	void setOutput(File output) {
		this.output = output;
	}

	private File getInput() {
		return this.input;
	}

	void setInput(File input) {
		this.input = input;
	}

	private String getTargetNameSpace() {
		return this.targetNameSpace;
	}

	void setTargetNameSpace(String targetNameSpace) {
		this.targetNameSpace = targetNameSpace;
	}

	void execute() throws IOException, WSDLException {
		String inputFileName = this.getInput().getAbsolutePath();
		String tempOutputDir = EnvironmentProperty.TemporaryDirectory
				.getValue();
		this.converter.convertFile(this.getTargetNameSpace(), inputFileName,
				tempOutputDir, false, false);
		File tmpOutput = getTemporaryOutputFile();
		this.copyContent(tmpOutput, this.getOutput());
		tmpOutput.delete();
	}

	private File getTemporaryOutputFile() {
		String fileName = this.getInput().getName();
		String strippedFileName = fileName.substring(0, fileName
				.lastIndexOf(suffixWsdl));
		String path = EnvironmentProperty.TemporaryDirectory.getValue()
				+ File.separator + strippedFileName + suffixTemporaryWsdl2;
		return new File(path);
	}

	private void copyContent(File fileInput, File fileOutput)
			throws IOException {
		FileInputStream input = new FileInputStream(fileInput);
		FileOutputStream output = new FileOutputStream(fileOutput);
		final int BUFFER_SIZE = 8192;
		final int EOF = 0;
		byte[] buffer = new byte[BUFFER_SIZE];
		for (int bytesRead = EOF; (bytesRead = input.read(buffer)) > EOF;) {
			output.write(buffer, 0, bytesRead);
		}
		input.close();
		output.close();
	}
}