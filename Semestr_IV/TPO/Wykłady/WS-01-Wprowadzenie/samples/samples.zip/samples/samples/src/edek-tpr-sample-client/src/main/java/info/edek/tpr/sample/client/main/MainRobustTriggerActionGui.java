package info.edek.tpr.sample.client.main;

import info.edek.tpr.sample.client.robustTriggerAction.RobustTriggerActionSampleServiceStub;
import info.edek.tpr.sample.client.robustTriggerAction.RobustTriggerActionSampleServiceStub.RobustTriggerActionRequest;
import info.edek.tpr.sample.client.util.Service;
import info.edek.tpr.sample.client.util.Utility;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SpringLayout;

import org.apache.axis2.AxisFault;
import org.apache.axis2.client.ServiceClient;

public class MainRobustTriggerActionGui extends JFrame implements
		ActionListener {

	private static final long serialVersionUID = 465320630720463494L;

	private RobustTriggerActionSampleServiceStub triggerActionSampleServiceStub;

	private ServiceClient serviceClient;

	private JButton btnTriggerAction;

	private MainRobustTriggerActionGui() {
		try {
			this.triggerActionSampleServiceStub = getRobustTriggerActionSampleServiceStub();
			this.serviceClient = this.triggerActionSampleServiceStub
					._getServiceClient();
			this.btnTriggerAction = new JButton("RobustTriggerAction");
			this.btnTriggerAction.addActionListener(this);
			Container content = this.getContentPane();
			SpringLayout layout = new SpringLayout();
			content.setLayout(layout);
			content.add(this.btnTriggerAction);
			final int DEFAULT_PADDING = 5;
			final int DEFAULT_WIDTH = 300;
			final int DEFAULT_HEIGHT = 200;
			layout.putConstraint(SpringLayout.WEST, this.btnTriggerAction,
					DEFAULT_PADDING, SpringLayout.WEST, content);
			layout.putConstraint(SpringLayout.NORTH, this.btnTriggerAction,
					DEFAULT_PADDING, SpringLayout.NORTH, content);
			layout.putConstraint(SpringLayout.SOUTH, this.btnTriggerAction,
					-DEFAULT_PADDING, SpringLayout.SOUTH, content);
			layout.putConstraint(SpringLayout.EAST, this.btnTriggerAction,
					-DEFAULT_PADDING, SpringLayout.EAST, content);
			this.pack();
			this.setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
			this.setVisible(true);
		} catch (AxisFault ex) {
			this.showMessageBox(ex);
		}
	}

	private static RobustTriggerActionRequest getRobustTriggerActionRequest() {
		RobustTriggerActionRequest request = new RobustTriggerActionRequest();
		request.setIn(Utility.getMessage());
		return request;
	}

	private static RobustTriggerActionSampleServiceStub getRobustTriggerActionSampleServiceStub()
			throws AxisFault {
		return new RobustTriggerActionSampleServiceStub(
				Service.RobustTriggerActionSampleService.getServiceUri());
	}

	private void showMessageBox(Throwable ex) {
		JOptionPane.showMessageDialog(this, ex);
	}

	public void actionPerformed(ActionEvent e) {
		try {
			RobustTriggerActionRequest request = getRobustTriggerActionRequest();
			this.triggerActionSampleServiceStub.robustTriggerAction(request);
		} catch (Throwable ex) {
			this.showMessageBox(ex);
		}
	}

	public static void main(String... args) {
		new MainRobustTriggerActionGui();
	}
}