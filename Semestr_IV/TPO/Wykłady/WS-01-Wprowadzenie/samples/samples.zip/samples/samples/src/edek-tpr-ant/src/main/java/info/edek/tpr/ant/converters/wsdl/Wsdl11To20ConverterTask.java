package info.edek.tpr.ant.converters.wsdl;

import java.io.File;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;

public final class Wsdl11To20ConverterTask extends Task {

	private final Wsdl11To20Converter converterImpl;

	public Wsdl11To20ConverterTask() {
		this.converterImpl = new Wsdl11To20Converter();
	}

	public void setInput(File input) {
		this.converterImpl.setInput(input);
	}

	public void setOutput(File output) {
		this.converterImpl.setOutput(output);
	}

	public void setTargetNameSpace(String targetNameSpace) {
		this.converterImpl.setTargetNameSpace(targetNameSpace);
	}

	public void execute() throws BuildException {
		try {
			this.converterImpl.execute();
		} catch (Throwable ex) {
			throw new BuildException(
					"exception occurred while formatting tagged input", ex);
		}
	}
}