package info.edek.tpr.sample.client.util;

public final class Utility {

	private Utility() {
	}

	private static final String MESSAGE = "message";

	private static final String RESPONSE_PREFIX = "RESPONSE: ";

	private static final String SERVICE_URI_PREFIX = "http://localhost:8081/axis2/services/";

	public static String getMessage() {
		return MESSAGE;
	}

	public static String getResponseMessage(Class<?> c, String message) {
		return c.getCanonicalName() + RESPONSE_PREFIX + message;
	}

	public static String getLoggerName(Class<?> c) {
		return c.getCanonicalName();
	}

	public static String getServiceUriPrefix() {
		return SERVICE_URI_PREFIX;
	}
}