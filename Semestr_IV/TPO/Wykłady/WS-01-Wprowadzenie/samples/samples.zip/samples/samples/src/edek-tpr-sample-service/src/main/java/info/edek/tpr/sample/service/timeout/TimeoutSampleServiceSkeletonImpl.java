package info.edek.tpr.sample.service.timeout;

import info.edek.tpr.sample.service.util.Utility;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.impl.Log4JLogger;

public class TimeoutSampleServiceSkeletonImpl implements
		TimeoutSampleServiceSkeletonInterface {

	private static final Log logger;

	private static final long SLEEP_TIME_MILLIS = 10000;

	static {
		logger = new Log4JLogger(Utility
				.getLoggerName(TimeoutSampleServiceSkeletonImpl.class));
	}

	public TimeoutEchoMessageResponse timeoutEchoMessage(
			TimeoutEchoMessageRequest request) {
		TimeoutEchoMessageResponse response = new TimeoutEchoMessageResponse();
		response.localOut = Utility.getResponseMessage(this.getClass(),
				request.localIn);
		try {
			Thread.sleep(SLEEP_TIME_MILLIS);
		} catch (InterruptedException ex) {
			logger.error("Exception has been caught", ex);
		}
		return response;
	}
}