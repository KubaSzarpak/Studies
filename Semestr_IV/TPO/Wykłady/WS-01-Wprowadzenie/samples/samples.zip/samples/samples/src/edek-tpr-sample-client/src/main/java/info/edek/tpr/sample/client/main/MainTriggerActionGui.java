package info.edek.tpr.sample.client.main;

import info.edek.tpr.sample.client.triggerAction.TriggerActionSampleServiceStub;
import info.edek.tpr.sample.client.triggerAction.TriggerActionSampleServiceStub.TriggerActionRequest;
import info.edek.tpr.sample.client.util.Service;
import info.edek.tpr.sample.client.util.Utility;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SpringLayout;

import org.apache.axis2.AxisFault;

public class MainTriggerActionGui extends JFrame implements ActionListener {

	private static final long serialVersionUID = 465320630720463494L;

	private TriggerActionSampleServiceStub triggerActionSampleServiceStub;

	private JButton btnTriggerAction;

	private MainTriggerActionGui() {
		try {
			this.triggerActionSampleServiceStub = getTriggerActionSampleServiceStub();
			this.btnTriggerAction = new JButton("TriggerAction");
			this.btnTriggerAction.addActionListener(this);
			Container content = this.getContentPane();
			SpringLayout layout = new SpringLayout();
			content.setLayout(layout);
			content.add(this.btnTriggerAction);
			final int DEFAULT_PADDING = 5;
			final int DEFAULT_WIDTH = 300;
			final int DEFAULT_HEIGHT = 200;
			layout.putConstraint(SpringLayout.WEST, this.btnTriggerAction,
					DEFAULT_PADDING, SpringLayout.WEST, content);
			layout.putConstraint(SpringLayout.NORTH, this.btnTriggerAction,
					DEFAULT_PADDING, SpringLayout.NORTH, content);
			layout.putConstraint(SpringLayout.SOUTH, this.btnTriggerAction,
					-DEFAULT_PADDING, SpringLayout.SOUTH, content);
			layout.putConstraint(SpringLayout.EAST, this.btnTriggerAction,
					-DEFAULT_PADDING, SpringLayout.EAST, content);
			this.pack();
			this.setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
			this.setVisible(true);
		} catch (AxisFault ex) {
			this.showMessageBox(ex);
		}
	}

	private static TriggerActionRequest getTriggerActionRequest() {
		TriggerActionRequest request = new TriggerActionRequest();
		request.setIn(Utility.getMessage());
		return request;
	}

	private static TriggerActionSampleServiceStub getTriggerActionSampleServiceStub()
			throws AxisFault {
		return new TriggerActionSampleServiceStub(
				Service.TriggerActionSampleService.getServiceUri());
	}

	private void showMessageBox(Throwable ex) {
		JOptionPane.showMessageDialog(this, ex);
	}

	public void actionPerformed(ActionEvent e) {
		try {
			TriggerActionRequest request = getTriggerActionRequest();
			this.triggerActionSampleServiceStub.triggerAction(request);
		} catch (Throwable ex) {
			this.showMessageBox(ex);
		}
	}

	public static void main(String... args) {
		new MainTriggerActionGui();
	}
}