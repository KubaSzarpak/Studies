
/**
 * SampleServiceSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.5.1  Built on : Oct 19, 2009 (10:59:00 EDT)
 */
    package info.edek.tpr.sample.service.simple;
    /**
     *  SampleServiceSkeleton java skeleton for the axisService
     */
    public class SampleServiceSkeleton implements SampleServiceSkeletonInterface{
        
         
        /**
         * Auto generated method signature
         * 
                                     * @param echoMessageRequest0
         */
        
                 public info.edek.tpr.sample.service.simple.EchoMessageResponse echoMessage
                  (
                  info.edek.tpr.sample.service.simple.EchoMessageRequest echoMessageRequest0
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#echoMessage");
        }
     
    }
    